Don't run long-quiet-input.txt without the -q/--quiet flag!
It produces a huge output file, and takes a long time to do it.

Execution times for our solution, running on the autograder:
    short-input.txt: 0.046s
    long-quiet-input.txt: 2.213s

